off=0.02;
i_z=intensity/(mean(intensity_ves)*long(1));
int=min(i_z):off:max(i_z);

values=zeros(1,length(int));



for i=1:length(int)-1
    
    aux=find(i_z<int(i+1) & i_z>int(i));
    
    values(i)=mean(long(aux));
    
    values(isnan(values)) = [];
    
   
end

loc=find(values>0);
values_n=values(loc);
int_n=int(loc);

int_n=int_n-int_n(1);


values_n=(values_n-values_n(1))/values_n(1);

i_z_108=intensity_T108A/(mean(intensity_ves_T108A)*long_T108A(1));

int_t=min(i_z_108):off:max(i_z_108);

values_t=zeros(1,length(int_t));

for i=1:length(int_t)-1
    
    aux=find(i_z_108<int_t(i+1) & i_z_108>int_t(i));
    
    values_t(i)=mean(long_T108A(aux));
    
    values_t(isnan(values)) = [];
    
end

loc=find(values_t>0);
values_nt=values_t(loc);
int_nt=int_t(loc);

values_nt=(values_nt-values_nt(1))/values_nt(1);

int_nt=int_nt-int_nt(1);



scatter(int_n,values_n, 70)
hold on
scatter(int_nt,values_nt,70)
